# PocketPixel Phase 6

Settings/polish pass.

Added:
- System / Light / Dark theme preference
- Independent debt, recurring, and monthly-summary notification toggles
- Safer JSON backup import validation
- Existing offline/local-first storage retained

Note: PIN/biometric toggles from Phase 5 remain a settings foundation; production lock-screen enforcement should be device-tested before release.
