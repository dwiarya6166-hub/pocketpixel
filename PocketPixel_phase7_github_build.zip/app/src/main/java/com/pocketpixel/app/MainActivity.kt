package com.pocketpixel.app

import android.content.Context
import android.os.Bundle
import android.content.Context
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val XP_BLUE = Color(0xFF0B63D1)
private val XP_LIGHT = Color(0xFFF5F8FC)
private val XP_BORDER = Color(0xFF6BA7E8)
private val XP_TEXT = Color(0xFF12345A)
private val GREEN = Color(0xFF168A3A)
private val RED = Color(0xFFD62F2F)
private val PURPLE = Color(0xFF7048B8)
private val ORANGE = Color(0xFFCE7200)

// Phase 3 ledger model.
data class Wallet(val id: Long, val name: String, val currency: String, val openingBalance: Long)
data class Category(val id: Long, val name: String, val kind: String)
data class Tx(val id: Long, val title: String, val amount: Long, val type: String, val categoryId: Long, val walletId: Long, val date: Long, val note: String)
data class Transfer(val id: Long, val fromWalletId: Long, val toWalletId: Long, val amount: Long, val date: Long, val note: String)
data class Loan(val id: Long, val person: String, val title: String, val amount: Long, val direction: String, val walletId: Long, val date: Long, val dueDate: Long?, val notes: String)
data class LoanPayment(val id: Long, val loanId: Long, val amount: Long, val date: Long, val note: String)
data class Recurring(val id: Long, val title: String, val amount: Long, val type: String, val categoryId: Long, val walletId: Long, val nextDate: Long, val interval: String, val endDate: Long?, val remainingCount: Int?, val note: String, val active: Boolean)
data class AppData(val wallets: List<Wallet>, val categories: List<Category>, val tx: List<Tx>, val transfers: List<Transfer>, val loans: List<Loan> = emptyList(), val loanPayments: List<LoanPayment> = emptyList(), val recurring: List<Recurring> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketPixelApp(this) }
    }
}

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("pocketpixel", Context.MODE_PRIVATE)

    fun load(): AppData = AppData(readWallets(), readCategories(), readTx(), readTransfers(), readLoans(), readLoanPayments(), readRecurring())

    private fun readWallets(): List<Wallet> {
        val raw = prefs.getString("wallets", null) ?: return listOf(
            Wallet(1, "Cash", "IDR", 2_450_000), Wallet(2, "Bank BCA", "IDR", 5_200_000), Wallet(3, "E-Wallet", "IDR", 1_340_000)
        )
        val a = JSONArray(raw)
        return List(a.length()) { i -> val o = a.getJSONObject(i); Wallet(o.getLong("id"), o.getString("name"), o.getString("currency"), o.getLong("openingBalance")) }
    }
    private fun readCategories(): List<Category> {
        val raw = prefs.getString("categories", null) ?: return defaultCategories()
        val a = JSONArray(raw)
        return List(a.length()) { i -> val o = a.getJSONObject(i); Category(o.getLong("id"), o.getString("name"), o.getString("kind")) }
    }
    private fun readTx(): List<Tx> {
        val raw = prefs.getString("tx", null) ?: return emptyList(); val a = JSONArray(raw)
        return List(a.length()) { i -> val o = a.getJSONObject(i); Tx(o.getLong("id"), o.getString("title"), o.getLong("amount"), o.getString("type"), o.getLong("categoryId"), o.getLong("walletId"), o.getLong("date"), o.optString("note", "")) }
    }
    private fun readTransfers(): List<Transfer> {
        val raw = prefs.getString("transfers", null) ?: return emptyList(); val a = JSONArray(raw)
        return List(a.length()) { i -> val o = a.getJSONObject(i); Transfer(o.getLong("id"), o.getLong("from"), o.getLong("to"), o.getLong("amount"), o.getLong("date"), o.optString("note", "")) }
    }

    private fun readLoans(): List<Loan> { val a=JSONArray(prefs.getString("loans", "[]")!!); return List(a.length()){i->val o=a.getJSONObject(i);Loan(o.getLong("id"),o.getString("person"),o.getString("title"),o.getLong("amount"),o.getString("direction"),o.getLong("walletId"),o.getLong("date"),if(o.isNull("dueDate"))null else o.optLong("dueDate"),o.optString("notes",""))} }
    private fun readLoanPayments(): List<LoanPayment> { val a=JSONArray(prefs.getString("loanPayments", "[]")!!); return List(a.length()){i->val o=a.getJSONObject(i);LoanPayment(o.getLong("id"),o.getLong("loanId"),o.getLong("amount"),o.getLong("date"),o.optString("note",""))} }
    private fun readRecurring(): List<Recurring> { val a=JSONArray(prefs.getString("recurring", "[]")!!); return List(a.length()){i->val o=a.getJSONObject(i);Recurring(o.getLong("id"),o.getString("title"),o.getLong("amount"),o.getString("type"),o.getLong("categoryId"),o.getLong("walletId"),o.getLong("nextDate"),o.getString("interval"),if(o.isNull("endDate"))null else o.optLong("endDate"),if(o.isNull("remainingCount"))null else o.optInt("remainingCount"),o.optString("note",""),o.optBoolean("active",true))} }

    fun save(data: AppData) {
        fun arr(block: (JSONArray) -> Unit): String = JSONArray().also(block).toString()
        val w = arr { a -> data.wallets.forEach { a.put(JSONObject().apply { put("id", it.id); put("name", it.name); put("currency", it.currency); put("openingBalance", it.openingBalance) }) } }
        val c = arr { a -> data.categories.forEach { a.put(JSONObject().apply { put("id", it.id); put("name", it.name); put("kind", it.kind) }) } }
        val t = arr { a -> data.tx.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("amount", it.amount); put("type", it.type); put("categoryId", it.categoryId); put("walletId", it.walletId); put("date", it.date); put("note", it.note) }) } }
        val tr = arr { a -> data.transfers.forEach { a.put(JSONObject().apply { put("id", it.id); put("from", it.fromWalletId); put("to", it.toWalletId); put("amount", it.amount); put("date", it.date); put("note", it.note) }) } }
        val l = arr { a -> data.loans.forEach { a.put(JSONObject().apply { put("id",it.id);put("person",it.person);put("title",it.title);put("amount",it.amount);put("direction",it.direction);put("walletId",it.walletId);put("date",it.date);if(it.dueDate==null)put("dueDate",JSONObject.NULL)else put("dueDate",it.dueDate);put("notes",it.notes) }) } }
        val lp = arr { a -> data.loanPayments.forEach { a.put(JSONObject().apply { put("id",it.id);put("loanId",it.loanId);put("amount",it.amount);put("date",it.date);put("note",it.note) }) } }
        val rc = arr { a -> data.recurring.forEach { a.put(JSONObject().apply { put("id",it.id);put("title",it.title);put("amount",it.amount);put("type",it.type);put("categoryId",it.categoryId);put("walletId",it.walletId);put("nextDate",it.nextDate);put("interval",it.interval);if(it.endDate==null)put("endDate",JSONObject.NULL)else put("endDate",it.endDate);if(it.remainingCount==null)put("remainingCount",JSONObject.NULL)else put("remainingCount",it.remainingCount);put("note",it.note);put("active",it.active) }) } }
        prefs.edit().putString("wallets", w).putString("categories", c).putString("tx", t).putString("transfers", tr).putString("loans",l).putString("loanPayments",lp).putString("recurring",rc).apply()
    }
    fun importJson(json: String): Boolean {
        return try {
            val root = JSONObject(json)
            if (root.optString("format") != "PocketPixel") return false
            val required = arrayOf("wallets","categories","tx","transfers","loans","loanPayments","recurring")
            if (required.any { !root.has(it) || root.opt(it) !is JSONArray }) return false
            prefs.edit().putString("wallets",root.getJSONArray("wallets").toString())
                .putString("categories",root.getJSONArray("categories").toString())
                .putString("tx",root.getJSONArray("tx").toString())
                .putString("transfers",root.getJSONArray("transfers").toString())
                .putString("loans",root.getJSONArray("loans").toString())
                .putString("loanPayments",root.getJSONArray("loanPayments").toString())
                .putString("recurring",root.getJSONArray("recurring").toString()).apply()
            true
        } catch (_: Exception) { false }
    }

    fun hidden() = prefs.getBoolean("hidden", true)
    fun setHidden(v: Boolean) = prefs.edit().putBoolean("hidden", v).apply()
}

private fun defaultCategories() = listOf(
    Category(1,"Food","Expense"), Category(2,"Shopping","Expense"), Category(3,"Transport","Expense"), Category(4,"Bills","Expense"), Category(5,"Entertainment","Expense"), Category(6,"Health","Expense"), Category(7,"Education","Expense"), Category(8,"Other","Expense"),
    Category(101,"Salary","Income"), Category(102,"Freelance","Income"), Category(103,"Business","Income"), Category(104,"Other Income","Income")
)

private fun balances(data: AppData): Map<Long, Long> {
    val r = data.wallets.associate { it.id to it.openingBalance }.toMutableMap()
    data.tx.forEach { if (it.type == "Income") r[it.walletId] = (r[it.walletId] ?: 0) + it.amount else r[it.walletId] = (r[it.walletId] ?: 0) - it.amount }
    data.transfers.forEach { r[it.fromWalletId] = (r[it.fromWalletId] ?: 0) - it.amount; r[it.toWalletId] = (r[it.toWalletId] ?: 0) + it.amount }
    return r
}

@Composable fun PocketPixelApp(context: Context) {
    val store = remember { Store(context) }
    var data by remember { mutableStateOf(store.load()) }
    val processed = remember { mutableStateOf(false) }
    if (!processed.value) { val nd = processRecurring(data); if(nd != data){ store.save(nd); data=nd }; processed.value=true; scheduleDueNotifications(context, data) }
    var hidden by remember { mutableStateOf(store.hidden()) }
    var tab by remember { mutableIntStateOf(0) }
    var editor by remember { mutableStateOf<Tx?>(null) }
    var addTx by remember { mutableStateOf(false) }
    var walletDialog by remember { mutableStateOf(false) }
    var transferDialog by remember { mutableStateOf(false) }
    var categoryDialog by remember { mutableStateOf(false) }
    fun persist(d: AppData) { data = d; store.save(d) }
    val wb = remember(data) { balances(data) }
    val income = data.tx.filter { it.type == "Income" }.sumOf { it.amount }
    val expense = data.tx.filter { it.type == "Expense" }.sumOf { it.amount }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = XP_LIGHT) {
            Column {
                XpTitleBar("PocketPixel")
                when (tab) {
                    0 -> Home(data, wb, hidden, income, expense, { hidden = !hidden; store.setHidden(hidden) }, { addTx = true }, { walletDialog = true }, { transferDialog = true })
                    1 -> TransactionsScreen(data, hidden, { t -> editor = t }, { id -> persist(data.copy(tx = data.tx.filterNot { it.id == id })) }, { addTx = true })
                    2 -> ReportScreen(data, wb, hidden)
                    3 -> LoanScreen(data, hidden, { d -> persist(d) })
                    else -> MoreScreen({ walletDialog = true }, { categoryDialog = true })
                }
                Spacer(Modifier.weight(1f)); BottomNav(tab) { tab = it }
            }
        }
    }

    if (addTx) TransactionEditor(data, null, { addTx = false }) { title, amount, type, cat, wallet, date, note ->
        persist(data.copy(tx = listOf(Tx(System.currentTimeMillis(), title, amount, type, cat, wallet, date, note)) + data.tx)); addTx = false
    }
    editor?.let { old -> TransactionEditor(data, old, { editor = null }) { title, amount, type, cat, wallet, date, note ->
        persist(data.copy(tx = data.tx.map { if (it.id == old.id) old.copy(title=title, amount=amount, type=type, categoryId=cat, walletId=wallet, date=date, note=note) else it })); editor = null
    } }
    if (walletDialog) WalletManager(data, wb, hidden, { walletDialog = false }) { persist(it) }
    if (transferDialog) TransferDialog(data, { transferDialog = false }) { persist(it); transferDialog = false }
    if (categoryDialog) CategoryManager(data, { categoryDialog = false }) { persist(it) }
}

@Composable fun XpTitleBar(title: String) = Row(Modifier.fillMaxWidth().background(XP_BLUE).border(2.dp, Color(0xFF8CC7FF)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
    Text(title, color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("— □ ×", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
}

@Composable fun Home(data: AppData, wb: Map<Long,Long>, hidden:Boolean, income:Long, expense:Long, toggle:()->Unit, add:()->Unit, wallets:()->Unit, transfer:()->Unit) {
    val cats = data.categories.associateBy { it.id }; val ws = data.wallets.associateBy { it.id }
    LazyColumn(Modifier.fillMaxWidth().weight(1f), contentPadding=PaddingValues(10.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item { XpPanel("Total Balance") { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { currencyTotals(data, wb).forEach { (currency, value) -> Text(if(hidden) "******** $currency" else "${money(value)} $currency", fontSize=24.sp, fontWeight=FontWeight.Bold, color=XP_TEXT) } }; Spacer(Modifier.width(8.dp)); Button(toggle){Text(if(hidden)"SHOW" else "HIDE")} } } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)){ Metric("↑ Income",income,hidden,GREEN,Modifier.weight(1f)); Metric("↓ Expenses",expense,hidden,RED,Modifier.weight(1f)) } }
        item { XpPanel("Wallets") { Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){ data.wallets.forEach{ WalletCard(it,wb[it.id]?:0,hidden) }; Box(Modifier.width(135.dp).height(105.dp).border(1.dp,XP_BORDER).background(Color.White).clickable{wallets()},contentAlignment=Alignment.Center){Text("+\nManage Wallets",color=XP_BLUE,textAlign=TextAlign.Center)} } } }
        item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(add,Modifier.weight(1f)){Text("+ TRANSACTION")}; Button(transfer,Modifier.weight(1f)){Text("↔ TRANSFER")} } }
        item { XpPanel("Recent Transactions") { data.tx.sortedByDescending{it.date}.take(6).forEach{t -> Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){ Text(if(t.type=="Income")"↑" else "↓",fontSize=20.sp,color=if(t.type=="Income")GREEN else RED,modifier=Modifier.width(28.dp)); Column(Modifier.weight(1f)){Text(t.title,color=XP_TEXT,fontWeight=FontWeight.SemiBold);Text("${cats[t.categoryId]?.name?:"Other"} • ${ws[t.walletId]?.name?:"Wallet"}",color=Color.Gray,fontSize=12.sp)};Text(if(hidden)"*****" else money(t.amount),color=if(t.type=="Income")GREEN else RED,fontWeight=FontWeight.Bold)};HorizontalDivider(color=XP_BORDER)} } }
    }
}
@Composable fun Metric(label:String,value:Long,hidden:Boolean,color:Color,modifier:Modifier){XpPanel(label,modifier){Text(if(hidden)"********" else money(value),color=color,fontSize=19.sp,fontWeight=FontWeight.Bold)}}
@Composable fun WalletCard(w:Wallet,balance:Long,hidden:Boolean)=Box(Modifier.width(135.dp).height(105.dp).border(1.dp,XP_BORDER).background(Color.White).padding(8.dp)){Column{Text("W",fontSize=18.sp,color=XP_BLUE,fontWeight=FontWeight.Bold);Text(w.name,color=XP_TEXT,fontWeight=FontWeight.Bold);Text(w.currency,color=Color.Gray,fontSize=12.sp);Text(if(hidden)"******" else money(balance),color=XP_TEXT,fontWeight=FontWeight.Bold)}}

@Composable fun TransactionsScreen(data:AppData,hidden:Boolean,onEdit:(Tx)->Unit,onDelete:(Long)->Unit,onAdd:()->Unit){
    var search by remember{mutableStateOf("")}; var filter by remember{mutableStateOf("All")}; val cats=data.categories.associateBy{it.id}; val ws=data.wallets.associateBy{it.id}
    val filtered=data.tx.sortedByDescending{it.date}.filter{(filter=="All"||it.type==filter)&&(search.isBlank()||it.title.contains(search,true)||(cats[it.categoryId]?.name?:("")).contains(search,true))}
    Column(Modifier.fillMaxWidth().weight(1f)){Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(search,{search=it},Modifier.weight(1f),singleLine=true,label={Text("Search")});Button(onAdd){Text("+")}};Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=10.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("All","Expense","Income").forEach{FilterChip(filter==it,{filter=it},label={Text(it)})}}
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){items(filtered,key={it.id}){t->XpPanel("${t.title} • ${formatDate(t.date)}"){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${cats[t.categoryId]?.name?:"Other"} • ${ws[t.walletId]?.name?:"Wallet"}",color=Color.Gray);if(t.note.isNotBlank())Text(t.note,color=XP_TEXT,fontSize=12.sp)};Text(if(hidden)"*****" else money(t.amount),color=if(t.type=="Income")GREEN else RED,fontWeight=FontWeight.Bold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick={onEdit(t)}){Text("EDIT")};TextButton(onClick={onDelete(t.id)}){Text("DELETE")}}}}}
    }
}

@Composable fun ReportScreen(data:AppData,wb:Map<Long,Long>,hidden:Boolean){
    val exp=data.tx.filter{it.type=="Expense"}.groupBy{it.categoryId}.mapValues{(_,v)->v.sumOf{it.amount}}.toList().sortedByDescending{it.second}; val inc=data.tx.filter{it.type=="Income"}.sumOf{it.amount}; val totalExp=exp.sumOf{it.second}; val cats=data.categories.associateBy{it.id}
    LazyColumn(Modifier.fillMaxWidth().weight(1f),contentPadding=PaddingValues(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{XpPanel("Summary"){Text("Income: ${if(hidden)"********" else money(inc)}",color=GREEN);Text("Expenses: ${if(hidden)"********" else money(totalExp)}",color=RED);Text("Net: ${if(hidden)"********" else money(inc-totalExp)}",color=XP_TEXT,fontWeight=FontWeight.Bold)}};item{XpPanel("Expense Donut"){if(exp.isEmpty())Text("No expense data yet")else DonutChart(exp.map{it.second},Modifier.fillMaxWidth().height(190.dp));exp.forEach{(id,a)->Row(Modifier.fillMaxWidth().padding(vertical=3.dp)){Text(cats[id]?.name?:"Other",Modifier.weight(1f),color=XP_TEXT);Text(if(hidden)"*****" else money(a),color=RED)}}}};item{XpPanel("Wallet Distribution"){val vals=data.wallets.map{wb[it.id]?:0};if(vals.any{it>0})DonutChart(vals,Modifier.fillMaxWidth().height(190.dp));data.wallets.forEach{w->Text("${w.name}: ${if(hidden)"******" else money(wb[w.id]?:0)} ${w.currency}",color=XP_TEXT)}}};item{XpPanel("Balance Trend"){val points=balanceSeries(data);if(points.size<2)Text("Add more transactions to see the trend")else LineChart(points,Modifier.fillMaxWidth().height(190.dp))}}
    }
}

@Composable fun DonutChart(values:List<Long>,modifier:Modifier){Canvas(modifier){val total=values.sum().coerceAtLeast(1);var start=-90f;val colors=listOf(XP_BLUE,GREEN,RED,PURPLE,ORANGE,Color(0xFF3D8C8C),Color(0xFF8A5A44));values.forEachIndexed{i,v->val sweep=360f*v/total;drawArc(colors[i%colors.size],start,sweep,false,style=Stroke(width=42f));start+=sweep};drawCircle(Color.White,radius=size.minDimension*.18f,center=Offset(size.width/2,size.height/2))}}
@Composable fun LineChart(points:List<Long>,modifier:Modifier){Canvas(modifier){val min=points.minOrNull()?:0;val max=points.maxOrNull()?:1;val span=(max-min).coerceAtLeast(1);val w=size.width;val h=size.height;val path=androidx.compose.ui.graphics.Path();points.forEachIndexed{i,v->val x=if(points.size==1)0f else w*i/(points.size-1);val y=h-((v-min).toFloat()/span*h);if(i==0)path.moveTo(x,y)else path.lineTo(x,y);drawCircle(XP_BLUE,4f,Offset(x,y))};drawPath(path,XP_BLUE,style=Stroke(width=5f))}}

private fun balanceSeries(data:AppData):List<Long>{var b=data.wallets.sumOf{it.openingBalance};val all=(data.tx.map{it.date to if(it.type=="Income")it.amount else -it.amount}+data.transfers.flatMap{listOf(it.date to -it.amount,it.date to it.amount)}).sortedBy{it.first};val r=mutableListOf<Long>();all.forEach{b+=it.second;r.add(b)};return r}

@Composable fun WalletManager(data:AppData,wb:Map<Long,Long>,hidden:Boolean,onDismiss:()->Unit,onChange:(AppData)->Unit){
    var edit by remember{mutableStateOf<Wallet?>(null)};var add by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Wallets")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){data.wallets.forEach{w->XpPanel(w.name){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${w.currency} • ${if(hidden)"******" else money(wb[w.id]?:0)}",color=XP_TEXT)};TextButton(onClick={edit=w}){Text("EDIT")};TextButton(onClick={if(data.wallets.size>1 && data.tx.none{it.walletId==w.id} && data.transfers.none{it.fromWalletId==w.id || it.toWalletId==w.id}) onChange(data.copy(wallets=data.wallets.filterNot{it.id==w.id}))}){Text("DEL")}}}};Button({add=true},Modifier.fillMaxWidth()){Text("+ ADD WALLET")}}},confirmButton={TextButton(onClick=onDismiss){Text("DONE")}})
    if(add||edit!=null)WalletEditor(edit,{add=false;edit=null;onDismiss()}){name,currency,balance->val w=edit;val nw=if(w==null)Wallet(System.currentTimeMillis(),name,currency,balance)else w.copy(name=name,currency=currency,openingBalance=balance);onChange(data.copy(wallets=if(w==null)data.wallets+nw else data.wallets.map{if(it.id==w.id)nw else it}));add=false;edit=null}
}
@Composable fun WalletEditor(existing:Wallet?,onDismiss:()->Unit,onSave:(String,String,Long)->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var currency by remember{mutableStateOf(existing?.currency?:"IDR")};var bal by remember{mutableStateOf(existing?.openingBalance?.toString()?:"0")};AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Add Wallet" else "Edit Wallet")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true);OutlinedTextField(currency,{currency=it.uppercase()},label={Text("Currency")},singleLine=true);OutlinedTextField(bal,{bal=it.filter(Char::isDigit)},label={Text("Opening Balance")},singleLine=true)}},confirmButton={TextButton(onClick={if(name.isNotBlank()&&bal.toLongOrNull()!=null)onSave(name,currency,bal.toLong())}){Text("SAVE")}},dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})}

@Composable fun TransferDialog(data:AppData,onDismiss:()->Unit,onSave:(AppData)->Unit){var from by remember{mutableLongStateOf(data.wallets.firstOrNull()?.id?:0)};var to by remember{mutableLongStateOf(data.wallets.drop(1).firstOrNull()?.id?:0)};var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Transfer")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("From",fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState())){data.wallets.forEach{FilterChip(from==it.id,{from=it.id},label={Text(it.name)})}};Text("To",fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState())){data.wallets.filter{it.id!=from}.forEach{FilterChip(to==it.id,{to=it.id},label={Text(it.name)})}};OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Amount")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Note")},singleLine=true)}},confirmButton={TextButton(onClick={val n=amount.toLongOrNull()?:0;val fw=data.wallets.firstOrNull{it.id==from};val tw=data.wallets.firstOrNull{it.id==to};if(from!=to&&n>0&&fw?.currency==tw?.currency)onSave(data.copy(transfers=data.transfers+Transfer(System.currentTimeMillis(),from,to,n,System.currentTimeMillis(),note)));onDismiss()}){Text("TRANSFER")}},dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})}

@Composable fun CategoryManager(data:AppData,onDismiss:()->Unit,onChange:(AppData)->Unit){var kind by remember{mutableStateOf("Expense")};var newName by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Categories")},text={Column{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(kind=="Expense",{kind="Expense"},label={Text("Expense")});FilterChip(kind=="Income",{kind="Income"},label={Text("Income")})};data.categories.filter{it.kind==kind}.forEach{c->Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Text(c.name,Modifier.weight(1f),color=XP_TEXT);if(c.id>8&&c.id<101||c.id>104)TextButton(onClick={onChange(data.copy(categories=data.categories.filterNot{it.id==c.id}))}){Text("DELETE")}}};OutlinedTextField(newName,{newName=it},label={Text("New category")},singleLine=true);Button({if(newName.isNotBlank()){val id=System.currentTimeMillis();onChange(data.copy(categories=data.categories+Category(id,newName,kind)));newName=""}},Modifier.fillMaxWidth()){Text("+ ADD")}}},confirmButton={TextButton(onClick=onDismiss){Text("DONE")}})}

@Composable fun MoreScreen(wallets:()->Unit,categories:()->Unit)=Column(Modifier.fillMaxWidth().weight(1f)){
    val context=LocalContext.current
    var pinEnabled by remember { mutableStateOf(context.getSharedPreferences("pp_settings",0).getBoolean("pin",false)) }
    var bioEnabled by remember { mutableStateOf(context.getSharedPreferences("pp_settings",0).getBoolean("bio",false)) }
    val prefs=context.getSharedPreferences("pp_settings",0)
    LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{XpPanel("Manage Data"){Button(wallets,Modifier.fillMaxWidth()){Text("WALLETS")};Button(categories,Modifier.fillMaxWidth()){Text("CATEGORIES")}}}
        item{XpPanel("Backup / Export"){
            Text("Portable JSON backup. Restore it on another PocketPixel install.",color=XP_TEXT)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Button({exportData=true},Modifier.weight(1f)){Text("EXPORT")}
                Button({importData=true},Modifier.weight(1f)){Text("IMPORT")}
            }
        }}
        item{XpPanel("Appearance"){
    val themePrefs=context.getSharedPreferences("pp_settings",0)
    var theme by remember { mutableStateOf(themePrefs.getString("theme","system") ?: "system") }
    Text("Theme: ${theme.uppercase()}",color=XP_TEXT)
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
        listOf("system","light","dark").forEach { t ->
            Button({theme=t;themePrefs.edit().putString("theme",t).apply()},Modifier.weight(1f)){Text(t.uppercase())}
        }
    }
}}
item{XpPanel("Notifications"){
    val np=context.getSharedPreferences("pp_notifications",0)
    var debt by remember { mutableStateOf(np.getBoolean("debt",true)) }
    var recurring by remember { mutableStateOf(np.getBoolean("recurring",true)) }
    var summary by remember { mutableStateOf(np.getBoolean("summary",true)) }
    Button({debt=!debt;np.edit().putBoolean("debt",debt).apply()},Modifier.fillMaxWidth()){Text("DEBT REMINDERS: ${if(debt)"ON" else "OFF"}")}
    Button({recurring=!recurring;np.edit().putBoolean("recurring",recurring).apply()},Modifier.fillMaxWidth()){Text("RECURRING: ${if(recurring)"ON" else "OFF"}")}
    Button({summary=!summary;np.edit().putBoolean("summary",summary).apply()},Modifier.fillMaxWidth()){Text("MONTHLY SUMMARY: ${if(summary)"ON" else "OFF"}")}
}}
item{XpPanel("Security"){
            Text("PIN lock: ${if(pinEnabled)"ON" else "OFF"}",color=XP_TEXT)
            Button({pinEnabled=!pinEnabled;prefs.edit().putBoolean("pin",pinEnabled).apply()},Modifier.fillMaxWidth()){Text(if(pinEnabled)"DISABLE PIN" else "ENABLE PIN")}
            Text("Biometric: ${if(bioEnabled)"ON" else "OFF"}",color=XP_TEXT)
            Button({bioEnabled=!bioEnabled;prefs.edit().putBoolean("bio",bioEnabled).apply()},Modifier.fillMaxWidth()){Text(if(bioEnabled)"DISABLE BIOMETRIC" else "ENABLE BIOMETRIC")}
        }}
        item{XpPanel("Recurring"){Text("Recurring transactions are processed locally when the app opens.",color=XP_TEXT);Text("Schedules persist offline.",color=XP_TEXT)}}
        item{XpPanel("Reminders"){Text("Loan due reminders are scheduled locally.",color=XP_TEXT)}}
    }
    if(exportData)ExportDialog(context){exportData=false}
    if(importData)ImportDialog(context){importData=false}
}

private fun exportJson(context: Context): String {
    val store = Store(context)
    val d = store.load()
    fun arr(block: (JSONArray) -> Unit): JSONArray = JSONArray().also(block)
    val root = JSONObject()
    root.put("format", "PocketPixel")
    root.put("version", 1)
    root.put("wallets", arr { a -> d.wallets.forEach { a.put(JSONObject().apply { put("id",it.id);put("name",it.name);put("currency",it.currency);put("openingBalance",it.openingBalance) }) } })
    root.put("categories", arr { a -> d.categories.forEach { a.put(JSONObject().apply { put("id",it.id);put("name",it.name);put("kind",it.kind) }) } })
    root.put("tx", arr { a -> d.tx.forEach { a.put(JSONObject().apply { put("id",it.id);put("title",it.title);put("amount",it.amount);put("type",it.type);put("categoryId",it.categoryId);put("walletId",it.walletId);put("date",it.date);put("note",it.note) }) } })
    root.put("transfers", arr { a -> d.transfers.forEach { a.put(JSONObject().apply { put("id",it.id);put("from",it.fromWalletId);put("to",it.toWalletId);put("amount",it.amount);put("date",it.date);put("note",it.note) }) } })
    root.put("loans", arr { a -> d.loans.forEach { a.put(JSONObject().apply { put("id",it.id);put("person",it.person);put("title",it.title);put("amount",it.amount);put("direction",it.direction);put("walletId",it.walletId);put("date",it.date);put("dueDate",it.dueDate ?: JSONObject.NULL);put("notes",it.notes) }) } })
    root.put("loanPayments", arr { a -> d.loanPayments.forEach { a.put(JSONObject().apply { put("id",it.id);put("loanId",it.loanId);put("amount",it.amount);put("date",it.date);put("note",it.note) }) } })
    root.put("recurring", arr { a -> d.recurring.forEach { a.put(JSONObject().apply { put("id",it.id);put("title",it.title);put("amount",it.amount);put("type",it.type);put("categoryId",it.categoryId);put("walletId",it.walletId);put("nextDate",it.nextDate);put("interval",it.interval);put("endDate",it.endDate ?: JSONObject.NULL);put("remainingCount",it.remainingCount ?: JSONObject.NULL);put("note",it.note);put("active",it.active) }) } })
    return root.toString()
}
@Composable fun ExportDialog(context:Context,onDismiss:()->Unit){
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
        if(uri!=null) context.contentResolver.openOutputStream(uri)?.use{it.write(exportJson(context).toByteArray())}
        onDismiss()
    }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Export Backup")},text={Text("Save all PocketPixel data as portable JSON.")},
        confirmButton={TextButton(onClick={launcher.launch("PocketPixel-backup.json")}){Text("SAVE")}},
        dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})
}
@Composable fun ImportDialog(context:Context,onDismiss:()->Unit){
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val json=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}
            if(!json.isNullOrBlank()) Store(context).importJson(json)
        }
        onDismiss()
    }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Import Backup")},text={Text("Replace local data with a PocketPixel JSON backup. Restart the app after importing.")},
        confirmButton={TextButton(onClick={launcher.launch(arrayOf("application/json","text/plain"))}){Text("OPEN")}},
        dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})
}
\n@Composable fun LoanScreen(data:AppData, hidden:Boolean, onChange:(AppData)->Unit) {
    var add by remember{mutableStateOf(false)}; var selected by remember{mutableStateOf<Loan?>(null)}
    val remaining={l:Loan->(l.amount-data.loanPayments.filter{it.loanId==l.id}.sumOf{it.amount}).coerceAtLeast(0)}
    Column(Modifier.fillMaxWidth().weight(1f)){ Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({add=true}){Text("+ LOAN")};Text("Track money lent / borrowed",Modifier.align(Alignment.CenterVertically),color=XP_TEXT)}
      LazyColumn(contentPadding=PaddingValues(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(data.loans){l->XpPanel("${l.direction}: ${l.person}"){Text(l.title,color=XP_TEXT,fontWeight=FontWeight.Bold);Text(if(hidden)"********" else "${money(remaining(l))} remaining");Text("Due: ${l.dueDate?.let{formatDate(it)}?:"—"}");Row{TextButton({selected=l}){Text("PAYMENT")};TextButton({onChange(data.copy(loans=data.loans.filterNot{it.id==l.id},loanPayments=data.loanPayments.filterNot{it.loanId==l.id}))}){Text("DELETE")}}}}}
    }
    if(add) LoanEditor(data,{add=false}){l->onChange(data.copy(loans=data.loans+l));add=false}
    selected?.let{l->PaymentEditor(l,{selected=null}){amt,note->onChange(data.copy(loanPayments=data.loanPayments+LoanPayment(System.currentTimeMillis(),l.id,amt,System.currentTimeMillis(),note)));selected=null}}
}
@Composable fun XpPanel(title:String,modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit)=Column(modifier.border(1.dp,XP_BORDER).background(Color.White)){Row(Modifier.fillMaxWidth().background(XP_BLUE).padding(horizontal=8.dp,vertical=5.dp)){Text(title,color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("×",color=Color.White,fontWeight=FontWeight.Bold)};Column(Modifier.padding(10.dp),content=content)}
@Composable fun BottomNav(selected:Int,onSelect:(Int)->Unit)=Row(Modifier.fillMaxWidth().background(XP_BLUE)){listOf("Home","Transactions","Report","Loan","More").forEachIndexed{i,n->Box(Modifier.weight(1f).height(62.dp).background(if(selected==i)Color(0xFF3F91E8)else XP_BLUE).border(1.dp,Color(0xFF8EC7FF)).clickable{onSelect(i)},contentAlignment=Alignment.Center){Text(n,color=Color.White,fontWeight=if(selected==i)FontWeight.Bold else FontWeight.Normal)}}}

@Composable fun TransactionEditor(data:AppData,existing:Tx?,onDismiss:()->Unit,onSave:(String,Long,String,Long,Long,Long,String)->Unit){var title by remember{mutableStateOf(existing?.title?:"")};var amount by remember{mutableStateOf(existing?.amount?.toString()?:"")};var type by remember{mutableStateOf(existing?.type?:"Expense")};var cat by remember{mutableLongStateOf(existing?.categoryId?:data.categories.first{it.kind=="Expense"}.id)};var wallet by remember{mutableLongStateOf(existing?.walletId?:data.wallets.firstOrNull()?.id?:1)};var date by remember{mutableStateOf(existing?.let{formatDate(it.date)}?:formatDate(System.currentTimeMillis()))};var note by remember{mutableStateOf(existing?.note?:"")};val cats=data.categories.filter{it.kind==type};AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"New Transaction" else "Edit Transaction")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("Title")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Amount")},singleLine=true);Row{FilterChip(type=="Expense",{type="Expense";cat=data.categories.first{it.kind=="Expense"}.id},label={Text("Expense")});Spacer(Modifier.width(5.dp));FilterChip(type=="Income",{type="Income";cat=data.categories.first{it.kind=="Income"}.id},label={Text("Income")})};Text("Category",fontWeight=FontWeight.Bold,color=XP_TEXT);Row(Modifier.horizontalScroll(rememberScrollState())){cats.forEach{FilterChip(cat==it.id,{cat=it.id},label={Text(it.name)})}};Text("Wallet",fontWeight=FontWeight.Bold,color=XP_TEXT);Row(Modifier.horizontalScroll(rememberScrollState())){data.wallets.forEach{FilterChip(wallet==it.id,{wallet=it.id},label={Text(it.name)})}};OutlinedTextField(date,{date=it.filter{c->c.isDigit()||c=='-'}},label={Text("Date YYYY-MM-DD")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Note")})}},confirmButton={TextButton(onClick={val n=amount.toLongOrNull();val d=parseDate(date);if(title.isNotBlank()&&n!=null&&n>0&&d!=null)onSave(title,n,type,cat,wallet,d,note)}){Text("SAVE")}},dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})}

private fun currencyTotals(data: AppData, wb: Map<Long, Long>): Map<String, Long> = data.wallets.groupBy { it.currency }.mapValues { (_, ws) -> ws.sumOf { wb[it.id] ?: 0 } }

private fun formatDate(ms:Long)=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(ms));private fun parseDate(s:String):Long?=try{SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(s)?.time}catch(_:Exception){null};private fun money(v:Long)=NumberFormat.getNumberInstance(Locale.US).format(v).replace(",",".")


@Composable fun LoanEditor(data:AppData,onDismiss:()->Unit,onSave:(Loan)->Unit){var person by remember{mutableStateOf("")};var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var dir by remember{mutableStateOf("LENT")};var wallet by remember{mutableLongStateOf(data.wallets.firstOrNull()?.id?:0)};var date by remember{mutableStateOf(formatDate(System.currentTimeMillis()))};var due by remember{mutableStateOf("")};var notes by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("New Loan / Debt")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(person,{person=it},label={Text("Person / entity")},singleLine=true);OutlinedTextField(title,{title=it},label={Text("Title")},singleLine=true);Row{FilterChip(dir=="LENT",{dir="LENT"},label={Text("I lent")});Spacer(Modifier.width(5.dp));FilterChip(dir=="BORROWED",{dir="BORROWED"},label={Text("I borrowed")})};OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Amount")},singleLine=true);Text("Wallet",fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState())){data.wallets.forEach{FilterChip(wallet==it.id,{wallet=it.id},label={Text(it.name)})}};OutlinedTextField(date,{date=it},label={Text("Date YYYY-MM-DD")},singleLine=true);OutlinedTextField(due,{due=it},label={Text("Due date YYYY-MM-DD (optional)")},singleLine=true);OutlinedTextField(notes,{notes=it},label={Text("Notes")})}},confirmButton={TextButton({val a=amount.toLongOrNull();val d=parseDate(date);if(person.isNotBlank()&&a!=null&&a>0&&d!=null)onSave(Loan(System.currentTimeMillis(),person,if(title.isBlank())"Loan" else title,a,dir,wallet,d,if(due.isBlank())null else parseDate(due),notes))}){Text("SAVE")}},dismissButton={TextButton(onDismiss){Text("CANCEL")}})}

@Composable fun PaymentEditor(loan:Loan,onDismiss:()->Unit,onSave:(Long,String)->Unit){var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Payment")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${loan.person} • ${loan.title}");OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Amount")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Note")})}},confirmButton={TextButton({amount.toLongOrNull()?.takeIf{it>0}?.let{onSave(it,note)}}){Text("SAVE")}},dismissButton={TextButton(onDismiss){Text("CANCEL")}})}

private fun addInterval(date:Long, interval:String):Long{val c=Calendar.getInstance().apply{timeInMillis=date};when(interval){"WEEKLY"->c.add(Calendar.DAY_OF_YEAR,7);"MONTHLY"->c.add(Calendar.MONTH,1);"YEARLY"->c.add(Calendar.YEAR,1)};return c.timeInMillis}
private fun processRecurring(data:AppData):AppData{val now=System.currentTimeMillis();val tx=data.tx.toMutableList();val rs=data.recurring.toMutableList();rs.forEachIndexed{idx,r->var next=r.nextDate;var count=r.remainingCount;while(r.active&&next<=now&&(r.endDate==null||next<=r.endDate)&&(count==null||count>0)){tx.add(Tx(System.currentTimeMillis()+tx.size,r.title,r.amount,r.type,r.categoryId,r.walletId,next,r.note));if(count!=null)count--;next=addInterval(next,r.interval);if(next>now)break};rs[idx]=r.copy(nextDate=next,remainingCount=count,active=r.active&&((r.endDate==null||next<=r.endDate)&&(count==null||count>0)))};return data.copy(tx=tx,recurring=rs)}

private const val CHANNEL="pocketpixel_reminders"
class ReminderReceiver:android.content.BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(CHANNEL,"PocketPixel Reminders",NotificationManager.IMPORTANCE_DEFAULT));val title=intent.getStringExtra("title")?:"PocketPixel reminder";val text=intent.getStringExtra("text")?:"Reminder";val n=NotificationCompat.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).setAutoCancel(true).build();nm.notify((System.currentTimeMillis()%100000).toInt(),n)}}
private fun scheduleDueNotifications(context:Context,data:AppData){val am=context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager;data.loans.filter{it.dueDate!=null&&it.dueDate>=System.currentTimeMillis()}.forEach{l->val i=Intent(context,ReminderReceiver::class.java).putExtra("title","Loan due: ${l.person}").putExtra("text",l.title);val pi=PendingIntent.getBroadcast(context,l.id.toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,l.dueDate!!,pi)else am.set(android.app.AlarmManager.RTC_WAKEUP,l.dueDate!!,pi)}}
